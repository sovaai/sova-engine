package InfEngine::Common::Functions;

use base 'Exporter';
@EXPORT_OK = qw( create_tmp_dir symlink create_dir create_tar_archive extract_from_tar_archive copy_if_remote copy move console_path );

use strict;
use warnings;

use File::Path 2.06 qw( make_path );
use File::Temp;
use POSIX qw( strftime );
use Try::Tiny;
use Cwd qw( abs_path );
use File::Spec::Functions qw( rel2abs );
use Net::SCP;

use InfEngine::Common::LogSystem;

use File::Basename;

# Установка высшего уровня безопасности при работе с временными файлами.
File::Temp->safe_level( File::Temp::HIGH );

# Создание новой директории.
sub create_dir {
	my $target_dir = shift @_;

	my $debug = DEBUGFUNCTION();
	DEBUGARG target_dir => $target_dir;

    if( ! -d $target_dir ) {
    	unless( make_path( $target_dir, { verbose => 0, mode => 0755, error => \my $error } ) ) {
        	my ( $file, $message ) = %{shift @$error};

        	die qq|Can't create directory "$file": $message\n|;
	    }
    }

    return $target_dir;
}

# Создание временной директории, которая удаляется при прекращении выполнения скрипта.
sub create_tmp_dir {
	my ( $parent_dir, %args ) = @_;

	my $debug = DEBUGFUNCTION();
	DEBUGARG parent_dir => $parent_dir, %args;

	create_dir( $parent_dir );
	
	my $prefix = exists $args{prefix} ? $args{prefix} : "";

	my $res = try {
		File::Temp->safe_level( File::Temp::STANDARD );
	    File::Temp->newdir( (strftime "$prefix%Y-%m-%d_%H-%M", localtime).'_XXXXXX', DIR => $parent_dir, CLEANUP => 1 );
	} catch {
		die qq|Can't create temporary folder in "$parent_dir".\n|;
	};
	DEBUG "Tmp directory: $res";
	return $res;
}

# Создание архива tar с сжатием gzip.
sub create_tar_archive {
	my %args = @_;

	my $name = $args{name} || die "Invalid argument 'name'";
	my $dir = $args{dir};
	my $files = $args{files} || die "Invalid argument 'files'";

	my $cmd = "tar czf ";

	$name =~ s/\\/\\\\/g;
	$name =~ s/\"/\\\"/g;
	$cmd .= qq|"$name"|;

	if( $dir ) {
		$dir =~ s/\\/\\\\/g;
		$dir =~ s/\"/\\\"/g;
		$cmd .= qq| -C "$dir"|;
	}
	$cmd .= qq| "|.join( qq|" "|, @$files ).qq|"|;
	my $res = `$cmd 2>&1`;
	if( $? >> 8 ) {
		die $res;
    }
    else {
    	return $name;
    }
}

sub extract_from_tar_archive {
	my ( $archive_path, $target_dir, %args ) = @_;

	if( !$archive_path ) {
		die "Invalid argument 'archive_path'"
	}

	if( !$target_dir ) {
		die "Invaid argument 'target_dir'"
	}

	if( $args{create} ) {
		create_dir( $target_dir );
	}

	my $cmd = "tar xf ";

	$archive_path =~ s/\\/\\\\/g;
	$archive_path =~ s/\"/\\\"/g;
	$cmd .= qq|"$archive_path"|;

	$target_dir =~ s/\\/\\\\/g;
	$target_dir =~ s/\"/\\\"/g;
	$cmd .= qq| -C "$target_dir"|;

	my $res = `$cmd 2>&1`;
	if( $? >> 8 ) {
		die $res;
    }
    else {
    	return $target_dir;
    }
}

sub symlink {
	my ( $from, $to, %args ) = @_;

	my $debug = DEBUGFUNCTION();
	DEBUGARG from => $from, to => $to, %args;

	my $cmd = $args{force} ? "ln -sfT $from $to" : "ln -s $from $to";

    my $res = `$cmd`;
    if( $? >> 8 ) {
    	die "Can't create symlink: $res\n";
    }

    return $to;
}

sub copy_if_remote {
	my ( $path, $tmppath ) = @_;

	if( !$tmppath ) {
		$tmppath = '/tmp'
	}
	
	if( $path =~ /[^\\]:/i ) {
		my $scp = Net::SCP->new( recursive => 1, auto_yes => 1, compress => 1 );
		my $name = fileparse( $path );
		if( $name =~ /^(.*[^\\])(:)(.*)$/i ) {
			$name = $3;
		}

		my $to = create_tmp_dir( "$tmppath", prefix => 'from_remote_' );
		if( !$scp->scp( $path, "$to/" ) ) {
			die ERROR( "Can't copy '$path' to '$to': $scp->{errstr}" )."\n";
		}

		return ("$to/$name", $to);
	}
	else {
		return ($path, undef);
	}	
}

sub copy {
	my ( $from, $to ) = @_;

	my $debug = DEBUGFUNCTION();
	DEBUGARG from => $from, to => $to;

	my $from_path = abs_path( rel2abs( "$from" ) ) || abs_path( "$from" );
	$from_path =~ s/\\/\\\\/g;
	$from_path =~ s/\"/\\\"/g;

	my $to_path = abs_path( rel2abs( "$to" ) ) || abs_path( "$to" );
	$to_path =~ s/\\/\\\\/g;
	$to_path =~ s/\"/\\\"/g;

	my $scp = Net::SCP->new( recursive => 1, auto_yes => 1, compress => 1 );

	if( !$scp->scp( $from_path, $to_path ) ) {
		die ERROR( "Can't copy '$from' to '$to': $scp->{errstr}" )."\n";
	}

	return undef;
}

sub move {
	my ( $from, $to ) = @_;

	my $debug = DEBUGFUNCTION();
	DEBUGARG from => $from, to => $to;

	my $from_path = abs_path( $from );
	$from_path =~ s/\\/\\\\/g;
	$from_path =~ s/\"/\\\"/g;

	my $to_path = abs_path( $to );
	$to_path =~ s/\\/\\\\/g;
	$to_path =~ s/\"/\\\"/g;

	my $res = `mv "$from_path" "$to_path" 2>&1`;
	if( $? >> 8 ) {
		die ERROR( "Can't copy '$from' to '$to': $res" )."\n";
	}

	return undef;
}

1
