package InfEngine::Server::Package;

use strict;
use warnings;

=head1 NAME

InfEngine::Server::Package - Manipulate InfEngine packages.

=head1 DESCRIPTION

The InfEngine::Server::Package module provides three functions, C<create>, C<check> and C<install>.

=cut

use File::Copy;
use File::Basename;

use InfEngine::Common::Functions qw( create_tmp_dir create_dir create_tar_archive extract_from_tar_archive );
use InfEngine::Common::Path::Functions;
use InfEngine::Common::LogSystem;
use InfEngine::Server;

# Paths.
use constant INF_ENGINE_PACKAGE_ENGINE_PATH		=>	iepath( 'engine' );
use constant INF_ENGINE_PACKAGE_DLDATA_PATH		=>	iepath( 'dldata.ie2' );
use constant INF_ENGINE_PACKAGE_ELDATA_PATH		=>	iepath( 'eldata.ie2' );
use constant INF_ENGINE_PACKAGE_ALIASES_PATH	=>	iepath( 'aliases.dl' );

sub create {	
	my ( $package_path, %args ) = @_;

	if( !$package_path ) {
		die ERROR "Package path is empty.";
	}
	$package_path = iepath( $package_path );

	foreach my $key ( keys %args ) {
		next if( !defined $args{$key} );
		if( $key eq 'output' ) {
			if( ref( $args{$key} ) ne "SCALAR" ) {
				die ERROR_ARG( $key, $args{$key} );
			}
		}
		elsif( $key eq 'dldata' || $key eq 'eldata' ) {
			if( $args{$key} ) {
				$args{$key} = iepath( $args{$key} );
				if( !$args{$key}->is_exists() ) {
					die ERROR uc( substr $key, 0, 3 ).substr( $key, 3 )." path is invalid: $args{$key}";
				}
			}
		}
		elsif( $key eq 'engine' ) {
			if( $args{$key} ) {
				$args{$key} = iepath( $args{$key} );
				if( !$args{$key}->is_dir() ) {
					die ERROR "Engine path is invalid: $args{$key}";
				}
			}
		}
		elsif( $key eq 'root_path' ) {
			$args{$key} = iepath( $args{$key} );
			if( !$args{$key} || !$args{$key}->is_dir() ) {
				die ERROR "Root path path is invalid: $args{$key}";
			}
		}
		elsif( $key eq 'aliases' ) {
			if( $args{$key} ) {
				$args{$key} = iepath( $args{$key} );
				if( !$args{$key}->is_file() ) {
					die ERROR "Aliases path is invalid: $args{$key}";
				}
			}
		}
		elsif( $key eq 'strict' || $key eq 'compilers' || $key eq 'tools' || $key eq 'libraries' ) {
			
		}
		else {
			WARN_ARG( $key, $args{$key} );
			delete $args{$key};
		}
	}

	my $server = InfEngine::Server->new( $args{root_path} );

	INFO "Creating package: $package_path";
	
	# Create temporary directory.
	my $working_obj = create_tmp_dir( $server->tmp_path() );
	my $working_dir = iepath( $working_obj );

	my $engine;
	if( exists $args{engine} && $args{engine} ) {
		$engine = InfEngine::Server::Engine->new( $args{engine} );
	}
	else {
		$engine = $server->release();
	}

	if( exists $args{dldata} ) {
		if( !$args{dldata} ) {
			if( exists $args{engine} && $server->release->dldata->is_file() ) {
				if( $engine->check( dldata => $server->release->dldata ) ) {
					$args{dldata} = $server->release->dldata;
				}
				elsif( $server->release->dlsources ) {
					$args{dlsources} = $server->release->dlsources;
				}
				else {
					die "There is no compatible DLData.";
				}
			}
			elsif( $server->release->dldata ) {
				$args{dldata} = $server->release->dldata;
			}
			else {
				die "There is no compatible DLData.";
			}
		}
		elsif( $args{dldata}->is_file() ) {
			if( exists $args{engine} ) {
				if( !$engine->check( dldata => $args{dldata} ) ) {
					die ERROR "Incompatible DL data and engine.";
				}
			}
		}
		else {
			$args{dlsources} = $args{dldata};
			delete $args{dldata};
		}

		if( exists $args{dlsources} )
		{
			INFO "Compile DLData: $args{dlsources}";
			$engine->compile_dldata( $args{dlsources},
									 $server->config( 'InfCompiler' ),
									 $working_dir + INF_ENGINE_PACKAGE_DLDATA_PATH,
									 output => $args{output},
									 ( exists $args{strict} ? "strict" : "" ) => ( exists $args{strict} ? $args{strict} : "" ),
									 aliases => ( exists $args{aliases} && $args{aliases} && $args{aliases}->is_file() ? $args{aliases} : undef ) );
			INFO "Adding DL data ( compiled from $args{dlsources} ) to package.";
		}
		else {
			INFO "Adding binary DL data to package: $args{dldata}";
			copy( $args{dldata}, $working_dir + INF_ENGINE_PACKAGE_DLDATA_PATH );
		}
	}

	if( exists $args{eldata} && defined $args{eldata} ) {
		if( !$args{eldata} ) {
			if( exists $args{engine} && $server->release->eldata->is_file() ) {
				if( $engine->check( eldata => $server->release->eldata ) ) {
					$args{eldata} = $server->release->eldata;
				}
				elsif( $server->release->elsources ) {
					$args{elsources} = $server->release->elsources;
				}
				else {
					die "There is no compatible ellipsis data.";
				}
			}
			elsif( $server->release->elsources ) {
				$args{eldata} = $server->release->elsources;
			}
			elsif( $server->release->eldata ) {
				$args{eldata} = $server->release->eldata;
			}
			else {
				die "There is no compatible ellipsis data.";
			}
		}
		elsif( $args{eldata}->is_file() ) {
			if( exists $args{engine} ) {
				if( !$engine->check( eldata => $args{eldata} ) ) {
					die ERROR "Incompatible ellipsis data and engine.";
				}
			}
		}
		else {
			$args{elsources} = $args{eldata};
			delete $args{eldata};
		}

		if( exists $args{elsources} )
		{
			INFO "Compile ellipsis data: $args{elsources}";
			$engine->compile_eldata( $args{elsources},
									 $server->config( 'EllipsisCompiler' ),
									 $working_dir + INF_ENGINE_PACKAGE_ELDATA_PATH,
									 output => $args{output} );
			INFO "Adding ellipsis data ( compiled from $args{elsources} ) to package.";
		}
		else {
			INFO "Adding binary ellipsis data to package: $args{eldata}";
			copy( $args{eldata}, $working_dir + INF_ENGINE_PACKAGE_ELDATA_PATH );
		}
	}

	if( exists $args{engine} ) {
		INFO "Adding engine to package: ".$engine->root_path();
		$engine->copy_engine( $working_dir + INF_ENGINE_PACKAGE_ENGINE_PATH,
							  compilers => $args{compilers},
							  tools => $args{tools},
							  libraries => $args{libraries} );
	}

	if( exists $args{aliases} ) {
		if( !$args{aliases} ) {
			if( $server->release->aliases ) {
				$args{aliases} = $server->release->aliases;
			}
			else {
				die ERROR "There is no aliases.";
			}
		}
		elsif( !$args{aliases}->is_file() ) {
			die ERROR "Invalid aliases path: $args{aliases}";
		}

		INFO "Adding aliases file to package: $args{aliases}";
		copy( $args{aliases}, $working_dir + INF_ENGINE_PACKAGE_ALIASES_PATH );
	}

	# Create target directory.
	create_dir( $package_path->parent() );

	# Create package from prepared files.
	INFO "Compress package to: $package_path";
	return create_tar_archive( name => $package_path, dir => $working_dir, files => [ '.' ] );
}

sub install {
	my ( $package_path, %args ) = @_;

	if( !$package_path ) {
		die ERROR_ARG( 'package_path', $package_path );
	}
	$package_path = iepath( $package_path );

	foreach my $key ( keys %args ) {
		if( $key eq 'output' ) {
			if( ref( $args{$key} ) ne "SCALAR" ) {
				die ERROR_ARG( $key, $args{$key} );
			}
		}
		elsif( $key eq 'root_path' ) {
			$args{$key} = iepath( $args{$key} );
			if( !$args{$key}->is_dir() ) {
				die ERROR_ARG( $key, $args{$key} );
			}
		}		
		elsif( $key eq 'engine' || $key eq 'compilers' || $key eq 'tools' || $key eq 'libraries' || $key eq 'dldata' || $key eq 'eldata' || $key eq 'aliases' ) {

		}
		else {
			WARN_ARG( $key, $args{$key} );
			delete $args{$key};
		}
	}

	my $server = InfEngine::Server->new( $args{root_path} );
	delete $args{root_path};

	INFO "Installing package: $package_path";
	
	# Create temporary directory.
	my $working_obj = create_tmp_dir( $server->tmp_path() );
	my $working_dir = iepath( $working_obj );

	# Unpack package.
	INFO "Extracting package to $working_dir";
	extract_from_tar_archive( $package_path, $working_dir );

	# Extract elements from package.
	my $engine = $working_dir->add( INF_ENGINE_PACKAGE_ENGINE_PATH );
	if( $engine->is_exists() && ( exists $args{engine} || exists $args{compilers} || exists $args{tools} ) ) {
		$args{engine} = InfEngine::Server::Engine->new( $engine );
		INFO "InfEngine ".$args{engine}->version()." will be installed from package.";
	}
	elsif( $server->release ) {
		delete $args{engine};
		delete $args{compilers};
		delete $args{tools};
	}
	else {
		die ERROR "There is no installed engine.";
	}
	
	if( ( exists $args{aliases} || exists $args{dldata} ) && $working_dir->add( INF_ENGINE_PACKAGE_ALIASES_PATH )->is_file() ) {
		$args{aliases} = $working_dir->add( INF_ENGINE_PACKAGE_ALIASES_PATH );
	}
	else {
		$args{aliases} = "";
	}

	if( exists $args{dldata} && $working_dir->add( INF_ENGINE_PACKAGE_DLDATA_PATH )->is_file() ) {
		$args{dldata} = $working_dir->add( INF_ENGINE_PACKAGE_DLDATA_PATH );
		if( !( $args{engine} || $server->release )->check( dldata => $args{dldata} ) ) {
			die ERROR "DL data is incompatible with InfEngine ".( $args{engine} || $server->release )->release->version;
		}
		INFO "DL data will be install from package.";
	}
	else {
		if( $args{engine} && $server->release->dldata->is_file() ) {
			if( $args{engine}->check( dldata => $server->release->dldata ) ) {
				$args{dldata} = $server->release->dldata;
				INFO "DL data binary will be copied.";
			}
			elsif( $server->release->dlsources ) {
				$args{dlsources} = $server->release->dlsources;
				delete $args{dldata};
				INFO "DL data will be recompiled.";
			}
			elsif( $server->release->dldata() ) {
				die ERROR "There is no compatible DL data.";
			}
			else {
				delete $args{dldata};
			}
		}
	}

	if( exists $args{eldata} && $working_dir->add( INF_ENGINE_PACKAGE_ELDATA_PATH )->is_file() ) {
		$args{eldata} = $working_dir->add( INF_ENGINE_PACKAGE_ELDATA_PATH );
		if( !( $args{engine} || $server->release )->check( eldata => $args{eldata} ) ) {
			die ERROR "Ellipsis data is incompatible with InfEngine ".$server->release->version;
		}
		INFO "Ellipsis data will be install from package.";
	}
	else {
		if( $args{engine} && $server->release->eldata->is_file() ) {
			if( $args{engine}->check( eldata => $server->release->eldata ) ) {
				$args{eldata} = $server->release->eldata;
				INFO "Ellipsis data binary will be copied.";
			}
			elsif( $server->release->elsources ) {
				$args{elsources} = $server->release->elsources;
				delete $args{eldata};
				INFO "Ellipsis data will be recompiled";
			}
			elsif( $server->release->dldata() ) {
				die ERROR "There is no compatible ellipsis data.";
			}
			else {
				delete $args{eldata};
			}
		}
	}
	
	if( exists $args{engine} ) {
		$server->install_engine( %args );
	}
	else {
		$server->update_data( %args );
	}
	
	return undef;
}

sub check {
	my ( $package_path, %args ) = @_;

	if( !$package_path ) {
		die ERROR "Package path is empty.";
	}
	$package_path = iepath( $package_path );

	foreach my $key ( keys %args ) {
		if( $key eq 'output' ) {
			if( ref( $args{$key} ) ne "SCALAR" ) {
				die ERROR_ARG( $key, $args{$key} );
			}
		}
		elsif( $key eq 'root_path' ) {
			$args{$key} = iepath( $args{$key} );
			if( !$args{$key} || !$args{$key}->is_dir() ) {
				die ERROR "Root path path is invalid: $args{$key}";
			}
		}
		else {
			WARN_ARG( $key, $args{$key} );
			delete $args{$key};
		}
	}

	my $server = InfEngine::Server->new( $args{root_path} );

	INFO "Checking package: $package_path";
	
	# Create temporary directory.
	my $working_obj = create_tmp_dir( $server->tmp_path() );
	my $working_dir = iepath( $working_obj );

	# Unpack package.
	INFO "Extracting package to $working_dir";
	extract_from_tar_archive( $package_path, $working_dir );

	# Check package.
	my $engine = $working_dir->add( INF_ENGINE_PACKAGE_ENGINE_PATH );
	if( !$engine->is_dir() ) {
		$engine = $server->release();
		INFO "Using current engine: ".$engine->root_path();
	}
	else {
		$engine = InfEngine::Server::Engine->new( $engine );
		INFO "Using engine from package.";
	}

	my $dldata = $working_dir->add( INF_ENGINE_PACKAGE_DLDATA_PATH );
	if( !$dldata->is_file() ) {
		$dldata = $server->release->dldata();
		if( $dldata ) {
			INFO "Using current DL data: $dldata";
		}
		else {
			INFO "No DL data was found.";
		}
	}
	else {
		INFO "Using DL data from package.";
	}

	my $eldata = $working_dir->add( INF_ENGINE_PACKAGE_ELDATA_PATH );
	if( !$eldata->is_file() ) {
		$eldata = $server->release->eldata();
		if( $eldata ) {
			INFO "Using current ellipsis data: $eldata";
		}
		else {
			INFO "No ellipsis data was found.";
		}
	}
	else {
		INFO "Using ellipsis data from package."
	}
	
	if( $dldata ) {
		INFO "Checking compatebility for DL data and engine.";
		if( !$engine->check( dldata => $dldata ) ) {
			die "Incompatible engine and DL data.\n";
		}
	}
	if( $eldata ) {
		INFO "Checking compatibility from ellipsis data and engine.";
		if( !$engine->check( eldata => $eldata ) ) {
			die "Incompatible engine and ellipsis data.\n";
		}
	}
	
	return undef;
}

1;
