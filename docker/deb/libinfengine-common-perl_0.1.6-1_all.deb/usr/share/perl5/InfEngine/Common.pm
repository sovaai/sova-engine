package InfEngine::Common;

use strict;
use warnings;

our $VERSION = 0.1.6;

1;
