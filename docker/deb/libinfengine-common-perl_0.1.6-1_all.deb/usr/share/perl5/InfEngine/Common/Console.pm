package InfEngine::Common::Console;

use base 'Exporter';
@EXPORT = qw( FAILED SUCCESS confirm GetOptions try catch iepath ERROR WARNING create_dir );

use strict;
use warnings;

use Term::ANSIColor;
use Getopt::Long;
use Try::Tiny;

use InfEngine::Common::LogSystem;
use InfEngine::Common::Path::Functions;
use InfEngine::Common::Functions qw( create_dir );

# Turn off output buffer and STDERR output.
STDOUT->autoflush( 1 );
STDERR->autoflush( 1 );

# Print failed message.
sub FAILED {
    my $error = shift;
    print colored( "[FAILED]", 'red' );
    print "\n\n";
    if( $error ) {
    	print $error;
    	print "\n\n";
    }
    return $error;
};

# Print success message.
sub SUCCESS {
    print colored( "[SUCCESS]", 'green' )."\n";
    return "";
}

sub confirm {
    my ( $question, %args ) = @_;

    my $timeout = $args{timeout} || 60;
    my $answers = $args{answers} || [ 'Yes', 'No' ];

    local $SIG{ALRM} = sub {
        print "\n\nUser response timeout.\n\n";
        exit 1;
    };
    alarm $timeout;

    print "\n$question ".( join "/", @$answers )." ";
    my $stop = 0;
    while( $stop == 0 ) {
        while( <STDIN> ) {
            foreach my $answer( @$answers ) {
                if( $_ =~ /^\s*$answer\s*$/xi ) {
                    print "\n";

                    alarm 0;
                    return $answer;
                }
            }
            print "  You must type \"Yes\" or \"No\" ";
            alarm $timeout;
        }
    }
}

# Catch exceptions and gracefully finalize script.
sub Abort($) {
    FAILED "Script was aborted.";
    INFO "Scrip was aborted by user.";

    # Close STDERR for prevent warning messages.
    close( STDERR );

    exit 1;
}
use sigtrap 'handler', \&Abort, qw( ALRM HUP KILL INT TERM QUIT );

1
