package InfEngine::Server::Config::Base;

use strict;
use warnings;

use InfEngine::Common::Path;

sub get {
	my ( $self, $section, $name ) = @_;

	if( !$name ) {
		$name = $section;
		$section = "";
	}

	return exists $self->{_config}{lc($section)}{lc($name)} ? $self->{_config}{lc($section)}{lc($name)} : undef;
}

sub set {
	my ( $self, $section, $name, $value ) = @_;

	if( !$value ) {
		$value = $name;
		$name = $section;
		$section = "";
	}

	$self->{_config}{lc($section)}{lc($name)} = $value;

	return $self;
}

sub path {
	return InfEngine::Common::Path->new( shift->{_path} );
}

1
