package InfEngine::Common::LogSystem;

use base 'Exporter';
@EXPORT = qw( ERROR DEBUG INFO WARNING DEBUGFUNCTION DEBUGARG ERROR_ARG WARN_ARG );


# use InfEngine::Common::Functions;
# use InfEngine::Server::Config;


use Try::Tiny;
use File::Basename;
use Log::Log4perl;

use strict;
use warnings;

sub open {
	# Get log file name.
    my $log_path = shift;

	# Close previously opened log.
	InfEngine::Common::LogSystem::close();
	
	# Open log file.
	my $res = undef;
	InfEngine::Common::Functions::create_dir( dirname( $log_path ) );

    my $sn = basename( $0 );

    Log::Log4perl::init( \qq|
        log4perl.category = INFO, Logfile
         
        log4perl.appender.Logfile = Log::Log4perl::Appender::File 
        log4perl.appender.Logfile.filename = $log_path
        log4perl.appender.Logfile.mode = append
        log4perl.appender.Logfile.autoflush = 1
        log4perl.appender.Logfile.size = 10485760
        log4perl.appender.Logfile.mLogfileax = 5
        log4perl.appender.Logfile.layout = Log::Log4perl::Layout::PatternLayout
        log4perl.appender.Logfile.layout.ConversionPattern = %d{dd.MM.yyyy HH:mm:ss} [ $sn : %P ] %p %m %n

        log4perl.appender.Screen = Log::Log4perl::Appender::Screen 
        log4perl.appender.Screen.layout = Log::Log4perl::Layout::PatternLayout
        log4perl.appender.Screen.layout.ConversionPattern =  %n \033[0;35m[LOG] %p %m \033[0m %n | );

    return undef;
}

sub close {
    if( Log::Log4perl->initialized() ) {
	   Log::Log4perl->get_logger->cleanup();
    }
    return undef;
}

sub DEBUG {
    my $ident = "    " x ( InfEngine::Common::LogSystem::Debug::level() );
    if( Log::Log4perl->initialized() ) {
        Log::Log4perl->get_logger()->debug( $ident, "|   ", @_ );
    }
    return shift @_;
}

sub INFO {
    if( Log::Log4perl->initialized() ) {
        Log::Log4perl->get_logger()->info( @_ );
    }
    return shift @_;
}

sub WARNING {
    if( Log::Log4perl->initialized() ) {
        Log::Log4perl->get_logger()->warn( [caller( 1 )]->[3].": ", @_ );
    }
    return shift @_;
}

sub ERROR {
    if( Log::Log4perl->initialized() ) {
        Log::Log4perl->get_logger()->error( [caller( 1 )]->[3].": ", @_ );
    }
    return shift @_;
}

sub DEBUGFUNCTION {
    my $function = shift;
    return InfEngine::Common::LogSystem::Debug->new( $function ? $function : (caller(1))[3] );
}

sub DEBUGARG {
    my ( %args ) = @_;
    foreach my $key ( sort keys %args ) {
        next if( !$args{$key} );
        DEBUG( "ARGS: $key = ".( $args{$key} ? $args{$key} : "" ) );        
    }
}

sub _ARG {
    my ( $key, $value ) = @_;
    my $caller = (caller(2))[3];
    if( !$caller ) {
        $caller = "";
    }
    else {
        $caller = "$caller()";
    }

    return "$caller: Invalid argument '$key': ".( $value ? $value : "" );
}

sub ERROR_ARG {
    my $msg = _ARG( @_ );
    if( Log::Log4perl->initialized() ) {
        Log::Log4perl->get_logger()->error( $msg );
    }
    return "$msg\n";
}

sub WARN_ARG {
    my $msg = _ARG( @_ );
    if( Log::Log4perl->initialized() ) {
        Log::Log4perl->get_logger()->warn( $msg );
    }
        return "$msg\n";
}


package InfEngine::Common::LogSystem::Debug;

my $level = 0;

sub new {
    my ( $class, $function ) = @_;

    InfEngine::Common::LogSystem::DEBUG( "=> ".( $function ? $function : (caller(1))[3] )."()" );

    $level++;

    return bless {

    }, $class;
}

sub level {
    return $level;
}

sub DESTROY {
    $level--;

    InfEngine::Common::LogSystem::DEBUG( "<=" );
}

1
