package InfEngine::Server::Config::InfEngine;

use strict;
use warnings;

use base 'InfEngine::Server::Config::Base';

use Cwd qw( abs_path );

use InfEngine::Common::LogSystem;

sub new {
	my ( $class, $path, $force ) = @_;
	my $self = bless {}, $class;
	if( $path ) {
		$self->load( $path, $force );
	}
	return $self;
}

sub load {
	my ( $self, $path, $force ) = @_;

	if( !defined $force ) {
		$force = 1;
	}

	delete $self->{_config};
	delete $self->{_path};

	open FILE, $path or do {
		if( $force ) {
			ERROR "Can't open config file '$path': $!";
			die "Can't open config path: $!\n";
		}
		else {
			return $self;
		}
	};

	my $section = "";
	while( my $string = <FILE> ) {
		$string =~ s/^\s+//;
		$string =~ s/\s+$//;

		if( $string =~ /^\/\// ) {
			# Skip comments.
		}
		elsif( $string =~ /^\[\s*(.*)\s*\]$/ ) {
			$section = lc( $1 );
			$section =~ s/\s+/ /g;
		}
		elsif( $string =~ /^([a-zA-Z0-9]+)\s*=\s*(.*)$/ ) {
			my $name = lc( $1 );
			my $value = $2;
			$name =~ s/\s+/ /g;
			$self->{_config}{$section}{$name} = $value;
		}
	}

	close FILE;

	$self->{_path} = abs_path( $path );

	return $self;
}

1
