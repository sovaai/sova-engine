package InfEngine::Server::Engine;

use strict;
use warnings;

=head1 NAME

InfEngine::Server::Engine - Manipulate of InfEngine.

=cut

use InfEngine::Common::Functions qw( create_dir create_tmp_dir copy symlink );
use InfEngine::Common::LogSystem;
use InfEngine::Common::Path::Functions;
use InfEngine::Common::Git;

use overload 
    '""' => sub { shift->{engine_dir}; },
    'eq' => sub { shift->{engine_dir} eq shift; };


# Paths.
use constant INF_ENGINE_PATH_BIN				=> iepath( 'bin' );
use constant INF_ENGINE_PATH_CONF				=> iepath( 'conf' );
use constant INF_ENGINE_PATH_LIB				=> iepath( 'lib' );
use constant INF_ENGINE_PATH_BUILD				=> iepath( 'build' );
use constant INF_ENGINE_PATH_DLDATA				=> iepath( 'dldata' );
use constant INF_ENGINE_PATH_DLSOURCES			=> iepath( 'sources' );
use constant INF_ENGINE_PATH_ELDATA				=> iepath( 'eldata' );
use constant INF_ENGINE_PATH_ELSOURCES			=> iepath( 'sources' );

use constant INF_ENGINE_PATH_FUNCTIONS			=> INF_ENGINE_PATH_LIB + 'functions';

use constant INF_ENGINE_PATH_BUILD_BIN			=> INF_ENGINE_PATH_BUILD + 'bin';
use constant INF_ENGINE_PATH_BUILD_LIB			=> INF_ENGINE_PATH_BUILD + 'lib';

# Binaries.
use constant INF_ENGINE_BINARY_COMPILER			=> INF_ENGINE_PATH_BIN + 'InfCompiler';
use constant INF_ENGINE_BINARY_SERVER			=> INF_ENGINE_PATH_BIN + 'InfServer';
use constant INF_ENGINE_BINARY_ELLIPSIS_CMP		=> INF_ENGINE_PATH_BIN + 'EllipsisCompiler';
use constant INF_ENGINE_BINARY_CHECK_SIGNATURE	=> INF_ENGINE_PATH_BIN + 'CheckSignature';
use constant AP_PROCESS_SERVER_BINARY			=> INF_ENGINE_PATH_BIN + 'ap-process-server';

# Binaries sets.
use constant INF_ENGINE_BINARIES_SERVER			=>	(
														AP_PROCESS_SERVER_BINARY,
														INF_ENGINE_PATH_BIN + 'InfServer',
														INF_ENGINE_PATH_BIN + 'CheckSignature'
													);
use constant INF_ENGINE_BINARIES_COMPILERS		=>	(
														INF_ENGINE_PATH_BIN + 'InfCompiler',
														INF_ENGINE_PATH_BIN + 'EllipsisCompiler'
													);
use constant INF_ENGINE_BINARIES_TOOLS			=>	(
														INF_ENGINE_PATH_BIN + 'InfServer'
													);

# Libraries sets.
use constant INF_ENGINE_LIBRARIES				=>	(
														INF_ENGINE_PATH_LIB + 'libClientLib.a',
														INF_ENGINE_PATH_LIB + 'libClientLib.dylib',
														INF_ENGINE_PATH_LIB + 'libClientLib.so'
													);

# Config paths.
use constant INF_ENGINE_CONFIG_FUNCTIONS		=> INF_ENGINE_PATH_CONF + 'functions.lst';

# Files.
use constant INF_ENGINE_FILE_BUILD				=> iepath( 'HEAD/InfEngine2/Build.hpp' );
use constant INF_ENGINE_FILE_DLDATA				=> iepath( 'dldata.ie2' );
use constant INF_ENGINE_FILE_ELDATA				=> iepath( 'eldata.ie2' );
use constant INF_ENGINE_FILE_ALIASES			=> iepath( 'aliases.dl' );
use constant INF_ENGINE_FILE_ENCODING			=> iepath( 'encoding.info' );

# Links.
use constant INF_ENGINE_LINK_DLDATA				=> INF_ENGINE_PATH_DLDATA + 'dldata.ie2';
use constant INF_ENGINE_LINK_DLSOURCES			=> INF_ENGINE_PATH_DLDATA + 'dlsources';
use constant INF_ENGINE_LINK_ELDATA				=> INF_ENGINE_PATH_ELDATA + 'eldata.ie2';
use constant INF_ENGINE_LINK_ELSOURCES			=> INF_ENGINE_PATH_ELDATA + 'elsources';
use constant INF_ENGINE_LINK_ALIASES			=> INF_ENGINE_PATH_DLDATA + 'aliases.dl';


=head2 new( $engine_dir )

Create new InfEngine::Server::Engine object.

	engine_dir - InfEngine root dir.

=cut
sub new {
	my ( $class, $engine_dir ) = @_;

	return bless {
		engine_dir => iepath( $engine_dir )
	}, $class;
}

=head2 check

Check compatibility target DL and/or ellipsis data and InfEngine.

	ARGUMENTS:
		dldata - path to target DL data.
		eldata - path to target ellipsis data.

=cut
sub check {
	my ( $self, %args ) = @_;

	if( !$args{dldata} && !$args{eldata} ) {
		return 0;
	}

	# Can't check compatibility if there is no special tool.
	if( !$self->{engine_dir}->is_file( INF_ENGINE_BINARY_CHECK_SIGNATURE ) ) {
		return 0;
	}

	my $cmd = $self->{engine_dir}->add( INF_ENGINE_BINARY_CHECK_SIGNATURE )->quoted().
			  " --inf-server=".$self->{engine_dir}->add( INF_ENGINE_BINARY_SERVER )->quoted().
			  " --functions=".$self->{engine_dir}->add( INF_ENGINE_CONFIG_FUNCTIONS )->quoted().
			  " --functions-root=".$self->{engine_dir}->add( INF_ENGINE_PATH_FUNCTIONS )->quoted();

	if( $args{dldata} ) {
		$cmd .= " --base=".iepath( $args{dldata} )->quoted();
	}

	if( $args{eldata} ) {
		$cmd .= " --ellibase=".iepath( $args{eldata} )->quoted();
	}
	
	return `$cmd 2>&1`, !( $? >> 8 );
}

=head2 copy_engine( $target_dir, %args )

Copy InfEngine without DL or ellipsis data to target directory.

	target_dir - target directory.

	ARGUMENTS:
		compilers - copy compilers.
		tools - copy tools.
		libraries - copy libraries.

=cut
sub copy_engine {
	my ( $self, $target_dir, %args ) = @_;

	$target_dir = iepath( $target_dir );

	if( !$target_dir ) {
		die ERROR "Missed ".__PACKAGE__."::build() argument: 'target_dir'";
	}
	
	if( !$target_dir->is_dir() ) {
		create_dir( $target_dir );
	}

	foreach my $file ( INF_ENGINE_BINARIES_SERVER ) {
		create_dir( $target_dir->add( $file )->parent() );
		copy( $self->{engine_dir} + $file, $target_dir + $file );
		chmod 0755, $target_dir + $file;
	}
	if( $args{compilers} ) {
		foreach my $file ( INF_ENGINE_BINARIES_COMPILERS ) {
			next if( !$self->{engine_dir}->is_file( $file ) );
			create_dir( $target_dir->add( $file )->parent() );
			copy( $self->{engine_dir} + $file, $target_dir + $file );
			chmod 0755, $target_dir + $file;
		}
	}
	if( $args{tools} ) {
		foreach my $file ( INF_ENGINE_BINARIES_TOOLS ) {
			next if( !$self->{engine_dir}->is_file( $file ) );
			create_dir( $target_dir->add( $file )->parent() );
			copy( $self->{engine_dir} + $file, $target_dir + $file );
			chmod 0755, $target_dir + $file;
		}		
	}
	foreach my $file ( INF_ENGINE_CONFIG_FUNCTIONS ) {
		next if( !$self->{engine_dir}->is_file( $file ) );
		create_dir( $target_dir->add( $file )->parent() );
		copy( $self->{engine_dir} + $file, $target_dir + $file );
	}

	if( $args{libraries} ) {
		foreach my $file ( INF_ENGINE_LIBRARIES ) {
			next if( !$self->{engine_dir}->is_file( $file ) );
			create_dir( $target_dir->add( $file )->parent() );
			copy( $self->{engine_dir} + $file, $target_dir + $file );
			chmod 0755, $target_dir + $file;
		}		
	}

	if( $self->{engine_dir}->is_file( INF_ENGINE_CONFIG_FUNCTIONS ) ) {
		open LISTFH, $self->{engine_dir} + INF_ENGINE_CONFIG_FUNCTIONS or
			die ERROR "Can't open file '".$self->{engine_dir}->add( INF_ENGINE_CONFIG_FUNCTIONS )."': $!";
		create_dir( $target_dir + INF_ENGINE_PATH_FUNCTIONS );
		while( my $string = <LISTFH> ) {
			copy( $self->{engine_dir} + INF_ENGINE_PATH_FUNCTIONS + $string, $target_dir + INF_ENGINE_PATH_FUNCTIONS + $string );
		}
		close LISTFH;
	}

	return $self;
}

=head2 build( $branch, %args )

Build engine from git repository.

	repository - git repository or source directory.
	branch     - branch or tag name (using git repository).

	ARGUMENTS:
		jobs      - build threads number.
		compilers - build compilers.
		tools     - build tools.
		libraries - build libraries.
		output    - reference to output variable.

=cut
sub build {
	my ( $self, $repository, $branch, %args ) = @_;

	if( !$repository || ref $repository ) {
		die ERROR "Invalid ".__PACKAGE__."::build() argument 'repository': ".( $repository ? $repository : 0 );
	}
	
	my $engine_dir = iepath( $repository );
	if( !$engine_dir->is_dir() ) {
		$engine_dir = undef
	} else {
		$branch = "";
	}

	if( !$engine_dir && (!$branch || ref $branch) ) {
		die ERROR "Invalid ".__PACKAGE__."::build() argument 'branch': ".( $branch ? $branch : 0 );
	}

	foreach my $key ( keys %args ) {
		if( $key eq 'jobs' ) {
			if( !$args{jobs} ) {
				$args{jobs} = 1;
			}
			elsif( ref $args{jobs} || !( $args{jobs} =~ /^\d+$/ ) ) {
				die ERROR "Invalid ".__PACKAGE__."::build() argument '$key': ".( $args{$key} ? $args{$key} : 0 );
			}
		}
		elsif( $key =~ /^(compilers|tools|libraries)$/ ) {
			if( ref $args{$key} ) {
				die ERROR "Invalid ".__PACKAGE__."::build() argument '$key': ".( $args{$key} ? $args{$key} : 0 );
			}
		}
		elsif( $key eq 'output' ) {
			if( !defined $args{$key} ) {
				delete $args{$key};
			}
			elsif( ref $args{$key} !~ /^SCALAR\(.*\)$/ ) {
				die ERROR "Invalid ".__PACKAGE__."::build() argument '$key': ".( $args{$key} ? $args{$key} : 0 );
			}
		}
		else {
			WARNING( "Unknown ".__PACKAGE__."::build() argument: '$key' = ".( $args{$key} ? $args{$key} : "" ) );
		}
	}

	INFO "Build Engine: Branch: $branch, jobs: $args{jobs}".
				( $args{compilers} ? "" : ", no compilers" ).
				( $args{tools} ? "" : ", no-tools" ).
				( $args{libraries} ? "" : " no-libraries" );

	# Get sources from Nanosemantics git repository.
	my $tmp_working_path = create_tmp_dir( $self->{engine_dir}, prefix => 'git' );
	my $working_dir = iepath( $tmp_working_path );

	if( $engine_dir ) {
		$working_dir = iepath( "$working_dir/src" );
		copy( "$engine_dir", $working_dir );
		INFO "Sources \"$repository\" cloned.";
	}
	else {
		my $git = InfEngine::Common::Git->new();
		$git->clone( $repository, $working_dir );
		INFO "Git repository \"$repository\" cloned.";

		$git->run( checkout => "$branch" );
		INFO "Branch \"$branch\" checkouted.";

		$git->run( submodule => 'init' );
		$git->run( submodule => 'update' );
		INFO "Submodules initialized.";
	}
	
	# Make build info.
	if( $working_dir->is_file( INF_ENGINE_FILE_BUILD ) && open( FILE, ">>".$working_dir->add( INF_ENGINE_FILE_BUILD ) ) ) {
		print FILE "\n";
		print FILE "#ifdef BuildSvnTagNanosemantics\n";
		print FILE "  #undef BuildSvnTagNanosemantics\n";
		print FILE "#endif\n";
		print FILE "#define BuildSvnTagNanosemantics \"$branch\"\n";
		
		my $ServerName = Sys::Hostname::hostname();
		$ServerName =~ s/\\/\\\\/g;
		$ServerName =~ s/"/\\"/g;
		$ServerName =~ s/\s+/ /g;
		$ServerName =~ s/^\s+//g;
		$ServerName =~ s/\s+$//g;
		print FILE "\n";
		print FILE "#ifdef ServerName\n";
		print FILE "  #undef ServerName\n";
		print FILE "#endif\n";
		print FILE "#define ServerName \"$ServerName\"\n";
		
		close FILE;
		INFO "Build.hpp prepared.";
	}

	my $build_path = $working_dir->add( INF_ENGINE_PATH_BUILD )->quoted();
	my $res = `cd $build_path 2>&1 && cmake . 2>&1`;
	die ERROR "$res" if( $? >> 8 );

	$res = `cd $build_path 2>&1 && make -j $args{jobs} 2>&1`;
	die ERROR "$res" if( $? >> 8 );
	INFO( "InfEngine has built." );

	foreach my $file ( INF_ENGINE_BINARIES_SERVER ) {
		create_dir( $self->{engine_dir}->add( $file )->parent() );
		copy( $working_dir + INF_ENGINE_PATH_BUILD_BIN + $file->name(), $self->{engine_dir} + $file );
		chmod 0755, $self->{engine_dir} + $file;
	}
	if( $args{compilers} ) {
		foreach my $file ( INF_ENGINE_BINARIES_COMPILERS ) {
			create_dir( $self->{engine_dir}->add( $file )->parent() );
			copy( $working_dir + INF_ENGINE_PATH_BUILD_BIN + $file->name(), $self->{engine_dir} + $file );
			chmod 0755, $self->{engine_dir} + $file;
		}
	}
	if( $args{tools} ) {
		foreach my $file ( INF_ENGINE_BINARIES_TOOLS ) {
			create_dir( $self->{engine_dir}->add( $file )->parent() );
			copy( $working_dir + INF_ENGINE_PATH_BUILD_BIN + $file->name(), $self->{engine_dir} + $file );
			chmod 0755, $self->{engine_dir} + $file;
		}		
	}
	
	create_dir( $self->{engine_dir}->add( INF_ENGINE_CONFIG_FUNCTIONS )->parent() );
	open FUNCTIONS, ">".$self->{engine_dir}->add( INF_ENGINE_CONFIG_FUNCTIONS ) or
		die ERROR "Can't open file '".$self->{engine_dir}->add( INF_ENGINE_CONFIG_FUNCTIONS )."': $!";

	opendir LIB, $working_dir->add( INF_ENGINE_PATH_BUILD_LIB ) or
		die ERROR "Can't open dir '".$working_dir->add( INF_ENGINE_PATH_BUILD_LIB )."': $!";
	foreach my $lib ( readdir LIB ) {
		next if( !$working_dir->is_file( INF_ENGINE_PATH_BUILD_LIB + $lib ) );
		if( $lib =~ /^libFunction.*\.(so|dylib)$/ ) {
			create_dir( $self->{engine_dir}->add( INF_ENGINE_PATH_FUNCTIONS ) );
			copy( $working_dir + INF_ENGINE_PATH_BUILD_LIB + $lib, $self->{engine_dir} + INF_ENGINE_PATH_FUNCTIONS );
			print FUNCTIONS "$lib\n";
		}
	}
	close LIB;
	close FUNCTIONS;

	if( $args{libraries} ) {
		foreach my $lib ( INF_ENGINE_LIBRARIES ) {
			if( $working_dir->add( INF_ENGINE_PATH_BUILD_LIB )->is_file( $lib->name() ) ) {
				copy( $working_dir + INF_ENGINE_PATH_BUILD_LIB + $lib->name(), $self->{engine_dir} + $lib );
			}
		}
	}

	INFO( "InfEngine prepared." );

	return $self;
}

=head2 compile_dldata( $dlsources, $configfile, $targetfile, %args )

Compile DL date from sources

	dlsources   - path to DL data sources.
	configfile  - path to InfCompiler config file.
	targetfile  - target DL data base path.

	ARGUMENTS:
		output      - reference to output variable.
		strict      - use strict DL compilation.

=cut
sub compile_dldata {
	my ( $self, $dlsources, $configfile, $targetfile, %args ) = @_;

	INFO "Compile DL data '$dlsources'";

	if( !$dlsources ) {
		die ERROR "Invalid DL data sources path: $dlsources";
	}

	if( !$configfile ) {
		die ERROR "Invalid InfCompiler config file path: $configfile";
	}

	if( !$targetfile ) {
		die ERROR "Invalid InfCompiler target path: $targetfile";
	}

	if( !$self->{engine_dir}->add( INF_ENGINE_BINARY_COMPILER )->is_file() ) {
		die ERROR "Invalid InfCompiler path: ".$self->{engine_dir}->add( INF_ENGINE_BINARY_COMPILER );
	}

	my $aliases_file = $args{aliases};
	if( !$aliases_file ) {
		$aliases_file = iepath( $dlsources )->add( INF_ENGINE_LINK_ALIASES );
		if( !$aliases_file->is_file() ) {
			$aliases_file = $self->{engine_dir}->add( INF_ENGINE_LINK_ALIASES );
			if( !$aliases_file->is_file() ) {
				$aliases_file = undef;
			}
		}
	}

	my $encoding = "";
	if( iepath( $dlsources )->add( INF_ENGINE_FILE_ENCODING )->is_file() ) {
		open ENCODINGFH, iepath( $dlsources )->add( INF_ENGINE_FILE_ENCODING ) or die ERROR "Can't open file: ".iepath( $dlsources )->add( INF_ENGINE_FILE_ENCODING );
		my $source;
		while( <ENCODINGFH> ) { $source .= $_ };
		$source =~ s/\s+/ /g;
		$source =~ s/^ //;
		$source =~ s/ $//;
		close ENCODINGFH;
		if( $source =~ /^UTF(-?)8$/i ) {
			$encoding = 'utf8';
		}
		elsif( $source =~ /^(CP|WIN)(-?)1251$/i ) {
			$encoding = 'cp1251';
		}
	}

	my $cmd = join " ", $self->{engine_dir}->add( INF_ENGINE_BINARY_COMPILER )->abs(),
				"--dldata-root" 	=> iepath( $dlsources )->abs(),
				"--functions-root" 	=> $self->{engine_dir}->add( INF_ENGINE_PATH_FUNCTIONS )->abs(),
				"--target-path" 	=> iepath( $targetfile )->abs(),
				"--strict" 			=> ( $args{strict} ? "true" : "false" ),
				( $aliases_file	? "--dlaliases"	: "" )	=> ( $aliases_file	? $aliases_file->abs()	: "" ),
				( $encoding		? "--encoding"	: "" )	=> ( $encoding		? $encoding				: "" ),
				iepath( $configfile )->abs(), "2>&1";

	my $res = `$cmd`;

	if( $args{output} ) {
		${$args{output}} .= $res;
	}

	if( $? >> 8 ) {
		unlink( $targetfile );
		ERROR( "Can't compile DL data: $res" );
		die "Can't compile DL data.\n";
	}

	INFO "DL data compiled.";

	return $self;
}

=head2 compile_eldata

Compile ellipsis date from sources

	elsources - path to ellipsis data sources.
	targetfile - directory for ellipsis data binary.

	ARGUMENTS:
		output      - reference to output variable.

=cut
sub compile_eldata {
	my ( $self, $elsources, $configfile, $targetfile, %args ) = @_;

	if( !$elsources ) {
		ERROR "Invalid DL data sources path:";
		die "Invalid DL data sources path.\n";
	}

	if( !$targetfile ) {
		ERROR "Invalid InfCompiler target path:";
		die "Invalid InfCompiler target path\n";
	}

	my $cmd = join " ", $self->{engine_dir}->add( INF_ENGINE_BINARY_ELLIPSIS_CMP )->abs(),
				"-root"			=> iepath( $elsources )->abs(),
				"--target-path" => iepath( $targetfile )->abs(),
				"$configfile", "2>&1";

	my $res = `$cmd`;
	if( $args{output} ) {
		${$args{output}} .= $res;
	}
	if( $? >> 8 ) {
		unlink( $targetfile );
		ERROR( "Can't compile ellipsis data: $res" );
		die "Can't compile ellipsis data.";
	}
	return $self;
}

=head2 install( %args )

Install DL or ellipsis data to InfEngine.

	ARGUMENTS:
		dldata - path to DL data binary.
		dlsources - path to DL data sources.
		eldata - path to ellipsis data binary.
		elsources - path to ellipsis data sources.

		aliases

=cut
sub install {
	my ( $self, %args ) = @_;

	# Check arguments.
	if( !$args{dldata} && !$args{eldata} ) {
		return $self;
	}

	# Install DLData.
	my ( $dldata_obj, $dldata_path );
	if( $args{dldata} ) {
		$dldata_obj = create_tmp_dir( $self->{engine_dir} + INF_ENGINE_PATH_DLDATA );
		$dldata_path = iepath( $dldata_obj );

		# Install aliases.
		if( !exists $args{aliases} || !$args{aliases} ) {
			# Keep aliases.
			if( $self->{engine_dir}->add( INF_ENGINE_LINK_ALIASES )->is_exists() ) {
				copy( $self->{engine_dir} + INF_ENGINE_LINK_ALIASES, $dldata_path + INF_ENGINE_FILE_ALIASES );
			}
		}
		elsif( $args{aliases}->is_file() ) {
			copy( $args{aliases}->abs(), $dldata_path->add( INF_ENGINE_FILE_ALIASES ) );
		}
		else {
			die ERROR "Invalid aliases path: $args{aliases}";
		}

		# Install DLData.
		$args{dldata} = iepath( $args{dldata} );
		if( !$args{dldata}->is_exists() ) {
			die ERROR "Invalid DLData path: $args{dldata}";
		}
		copy( $args{dldata}, $dldata_path + INF_ENGINE_FILE_DLDATA );

		# Install DLData sources.
		if( $args{dlsources} ) {
			$args{dlsources} = iepath( $args{dlsources} );
			if( !$args{dlsources}->is_dir() ) {
				die ERROR "Invalid DLData sources path: $args{dlsources}";
			}
			copy( $args{dlsources}, $dldata_path + INF_ENGINE_PATH_DLSOURCES );

			# Install aliases from DLData sources.
			my $aliases = $args{dlsources} + INF_ENGINE_FILE_ALIASES;
			if( $aliases->is_exists() ) {
				if( !$aliases->is_file() ) {
					die ERROR "Invalid aliases in DLData sources: $args{dlsources}";
				}

				if( !exists $args{aliases} || defined $args{aliases} && !$args{aliases} ) {
					copy( $aliases, $dldata_path + INF_ENGINE_FILE_ALIASES );
				}
			}
		}
	}

	# Install ellipsis data.
	my ( $eldata_obj, $eldata_path );
	if( exists $args{eldata} && defined $args{eldata} ) {
		$eldata_obj = create_tmp_dir( $self->{engine_dir} + INF_ENGINE_PATH_ELDATA );
		$eldata_path = iepath( $eldata_obj );

		$args{eldata} = iepath( $args{eldata} );
		if( !$args{eldata}->is_exists() ) {
			die ERROR "Invalid ellipsis data path: $args{eldata}";
		}
		copy( $args{eldata}, $eldata_path + INF_ENGINE_FILE_ELDATA );
		if( $args{elsources} ) {
			$args{elsources} = iepath( $args{elsources} );
			if( !$args{elsources}->is_dir() ) {
				die ERROR "Invalid ellipsis sources path: $args{elsources}";
			}
			copy( $args{elsources}, $eldata_path + INF_ENGINE_PATH_ELSOURCES );
		}
	}


	# Switch softlinks.
	if( $args{dldata} ) {
		symlink( $dldata_path->add( INF_ENGINE_FILE_DLDATA )->rel( $self->{engine_dir} + INF_ENGINE_PATH_DLDATA ),
				 $self->{engine_dir} + INF_ENGINE_LINK_DLDATA, force => 1 );
		$dldata_obj->unlink_on_destroy( 0 );

		if( $dldata_path->add( INF_ENGINE_PATH_DLSOURCES )->is_exists() ) {
			symlink( $dldata_path->add( INF_ENGINE_PATH_DLSOURCES )->rel( $self->{engine_dir} + INF_ENGINE_PATH_DLDATA ),
					 $self->{engine_dir} + INF_ENGINE_LINK_DLSOURCES, force => 1 );
		}
		else {
			$self->{engine_dir}->add( INF_ENGINE_LINK_DLSOURCES )->remove();	
		}

		if( $dldata_path->add( INF_ENGINE_FILE_ALIASES )->is_exists() ) {
			symlink( $dldata_path->add( INF_ENGINE_FILE_ALIASES )->rel( $self->{engine_dir} + INF_ENGINE_PATH_DLDATA ),
					 $self->{engine_dir} + INF_ENGINE_LINK_ALIASES, force => 1 );
		}
		else {
			$self->{engine_dir}->add( INF_ENGINE_LINK_ALIASES )->remove();
		}
	}

	if( $args{eldata} ) {
		symlink( $eldata_path->add( INF_ENGINE_FILE_ELDATA )->rel( $self->{engine_dir} + INF_ENGINE_PATH_ELDATA ),
				 $self->{engine_dir} + INF_ENGINE_LINK_ELDATA, force => 1 );
		$eldata_obj->unlink_on_destroy( 0 );

		if( $eldata_path->add( INF_ENGINE_PATH_ELSOURCES )->is_exists() ) {
			symlink( $eldata_path->add( INF_ENGINE_PATH_ELSOURCES )->rel( $self->{engine_dir} + INF_ENGINE_PATH_ELDATA ),
					 $self->{engine_dir} + INF_ENGINE_LINK_ELSOURCES, force => 1 );
		}
		else {
			$self->{engine_dir}->add( INF_ENGINE_LINK_ELSOURCES )->remove();
		}
	}

	return $self;
}

=head2 dldata( $force )

Get path to current DL data or undef if there is no DL data.

=over

=over

=item force

Return path even though it doesn't exists.

=back

=back

=cut
sub dldata {
	my $dldata = shift->{engine_dir} + INF_ENGINE_LINK_DLDATA;
	return !shift && !$dldata->is_file() ? iepath : $dldata;
}

sub dldatamd5 {
	# Вычисление md5.
	my $path = shift->dldata();
	my $cmd = 'md5sum '.$path;
	my $res = `$cmd`;
	if( $? >> 8 ) {
		die ERROR "Can't compute dldata checksum for '$path'.";
	}

	# Выделение md5.
	my @md5_parts = split( ' ', $res );
	if( scalar @md5_parts >= 1 ) {
		return $md5_parts[0];
	}

	die "Can't parse dldata checksum result.";
}

=head2 dlsources( $force )

Get path to current DL data sources or undef if there is no DL data sources.

=over

=over

=item force

Return path even though it doesn't exists.

=back

=back

=cut
sub dlsources {
	my $dlsources = shift->{engine_dir} + INF_ENGINE_LINK_DLSOURCES;
	return !shift && !$dlsources->is_dir() ? iepath : $dlsources;
}

=head2 eldata( $force )

Get path to current ellipsis data or undef if there is no ellipsis data.

=over

=over

=item force

Return path even though it doesn't exists.

=back

=back

=cut
sub eldata {
	my $eldata = shift->{engine_dir} + INF_ENGINE_LINK_ELDATA;
	return !shift && !$eldata->is_file() ? iepath : $eldata;
}

=head2 elsources( $force )

Get path to current ellipsis data or undef if there is no ellipsis data.

=over

=over

=item force

Return path even though it doesn't exists.

=back

=back

=cut
sub elsources {
	my $elsources = shift->{engine_dir} + INF_ENGINE_LINK_ELSOURCES;
	return !shift && !$elsources->is_dir() ? iepath : $elsources;
}

=head2 aliases( $force )

Get path to current alises file or undef if there is no aliases file.

=over

=over

=item force

Return path even though it doesn't exists.

=back

=back

=cut
sub aliases {
	my $aliases = shift->{engine_dir} + INF_ENGINE_LINK_ALIASES;
	return !shift && !$aliases->is_file() ? iepath : $aliases;
}

sub _clean {
	my ( $dir, $exclude, $limit ) = @_;

	if( !defined $limit ) {
		$limit = 0;
	}

	my $counter = 0;
	return 0 if( !$dir->is_dir() );
	
	my @files;
	opendir DIR, $dir or die ERROR "Can't open directory '$dir': $!";
	foreach my $file ( sort { $b cmp $a } readdir DIR ) {

		# Pass . and .. dirs.
		next if $file =~ /^\.\.?$/;

		my $file = $dir + $file;

		next if( $file->is_link() );

		$file = $file->real();

		next if( $file eq $exclude );

		push @files, $file;
	}
	closedir DIR;

	foreach ( 1..$limit ) {
		shift @files;
	}

	foreach my $file ( @files ) {
		$file->remove();
	}
	
	return scalar( @files );
};

=head2 clean()

Clean old releases, DL/ellipsis data and engines.

=cut
sub clean {
	my ( $self, $dllimit, $ellimit ) = @_;

	# Clean engines.
	my $count = _clean(
			$self->{engine_dir} + INF_ENGINE_PATH_DLDATA,
			$self->{engine_dir}->add( INF_ENGINE_LINK_DLDATA )->real()->parent(),
			$dllimit );
	if( $count ) {
		INFO "Deleted $count DLData.";
	};

	# Clean releases.
	$count = _clean(
			$self->{engine_dir} + INF_ENGINE_PATH_ELDATA,
			$self->{engine_dir}->add( INF_ENGINE_LINK_ELDATA )->real()->parent(),
			$ellimit );
	if( $count ) {
		INFO "Deleted $count ELData.";
	};

	return $self;
}

=head2 version()

Get InfEngine version.

=cut
sub version {
	my $self = shift @_;
	my $server = $self->{engine_dir} + INF_ENGINE_BINARY_SERVER;
	if( $server->is_file() ) {
		my $res = `$server --version`;
		if( $? >> 8 ) {
			die ERROR "Can't get InfEngine version: $res";
		}
		if( $res =~ /Release version: ([0-9a-zA-Z\.-]+)/ ) {
			return $1;
		}
	}
	return undef;
}

=head2 root_path()

Get current root path.

=cut
sub root_path {
	return shift->{engine_dir};
}

sub get {
	my ( $self, $name ) = @_;
	if( $name eq 'ap-process-server' ) {
		return $self->{engine_dir} + AP_PROCESS_SERVER_BINARY;
	}
	else {
		return iepath();
	}
}

1
