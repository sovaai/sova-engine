package InfEngine::Server::Config::ProcessServer;

use strict;
use warnings;

use base 'InfEngine::Server::Config::Base';

use Cwd qw( abs_path );

use InfEngine::Common::LogSystem;

sub new {
	my ( $class, $path, $force ) = @_;
	my $self = bless {}, shift;
	if( $path ) {
		$self->load( $path, $force );
	}
	return $self;
}

sub load {
	my ( $self, $path, $force ) = @_;

	if( !defined $force ) {
		$force = 1;
	}

	delete $self->{_config};
	delete $self->{_path};

	open FILE, $path or do {
		if( $force ) {
			ERROR "Can't open process server config file '$path': $!";
			die "Can't open process server config path: $!\n";
		}
		else {
			return $self;
		}
	};

	while( my $string = <FILE> ) {
		$string =~ s/^\s+//;
		$string =~ s/\s+$//;

		if( $string =~ /^#/ ) {
			# Skip comments.
		}
		elsif( $string =~ /^([a-zA-Z0-9]+)\s+(.*)$/ ) {
			$self->{_config}{""}{lc($1)} = $2;
		}
	}

	close FILE;

	$self->{_path} = abs_path( $path );

	return $self;
}

1
