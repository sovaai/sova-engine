package InfEngine::Common::Path::Functions;

use base 'Exporter';
@EXPORT = qw( iepath iepath_abs );

use strict;
use warnings;

use InfEngine::Common::Path;

sub iepath {
	return InfEngine::Common::Path->new( shift, shift );
}

sub iepath_abs {
	return iepath( @_ )->abs();
}

1
