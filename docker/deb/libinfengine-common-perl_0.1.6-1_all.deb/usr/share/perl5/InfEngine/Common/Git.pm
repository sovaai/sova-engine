package InfEngine::Common::Git;

use strict;
use warnings;

use Git::Repository;

sub new {
	return bless {}, shift;
}

sub clone {
	my ( $self, $repository, $path ) = @_;
	
	my $msg = "";
	local $SIG{__WARN__} = sub {
		$msg .= shift;
	};
	
	Git::Repository->run( clone => "$repository", "$path", { env => { GIT_WORK_TREE => undef } } );
	if( $? >> 8 ) {
		die "Can't clone repository '$repository' to '$path': $msg";
	}

	$self->{git} = Git::Repository->new( work_tree => "$path" );

	return $self;
}

sub run {
	my ( $self, @args ) = @_;

	my $msg = "";
	local $SIG{__WARN__} = sub {
		$msg .= shift;
	};

	$self->{git}->run( @args, { env => { GIT_WORK_TREE => undef } } );
	if( $? >> 8 ) {
		 die "Git error: $msg"
	}

	return $self;
}

1