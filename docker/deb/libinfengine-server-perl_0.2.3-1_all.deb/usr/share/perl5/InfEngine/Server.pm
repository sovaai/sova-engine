package InfEngine::Server;

use strict;
use warnings;

our $VERSION = 0.2.3;

=head1 NAME

InfEngine::Server - Manipulate InfEngine server.

=cut

use Fcntl qw( :flock );
use IPC::Run qw( run io );
use Try::Tiny;
use Cache::Memcached;

use InfEngine::Server::Config;
use InfEngine::Server::Engine;
use InfEngine::Common::Functions qw( create_tmp_dir create_dir symlink copy );
use InfEngine::Common::LogSystem;
use InfEngine::Common::Path::Functions;

# Paths.
use constant INF_ENGINE_PATH_DATA					=> iepath( 'data' );
use constant INF_ENGINE_PATH_TMP					=> iepath( 'tmp' );
use constant INF_ENGINE_PATH_CONF					=> iepath( 'conf' );
use constant INF_ENGINE_PATH_BIN					=> iepath( 'bin' );
use constant INF_ENGINE_PATH_LOGS					=> iepath( 'logs' );

use constant INF_ENGINE_PATH_ENGINES				=> INF_ENGINE_PATH_DATA + 'engine';
use constant INF_ENGINE_PATH_RELEASES				=> INF_ENGINE_PATH_DATA + 'release';

# Links.
use constant INF_ENGINE_LINK_READY					=> iepath( 'ready' );
use constant INF_ENGINE_LINK_RELEASE				=> iepath( 'release' );

# Filenames.
use constant INF_ENGINE_DLDATA_FILE					=> iepath( 'dldata.ie2' );
use constant INF_ENGINE_ELDATA_FILE					=> iepath( 'eldata.ie2' );

# Default root InfEngine server directory.
use constant INF_ENGINE_DEFAULT_ROOT_DIRECTORY		=> iepath( '/usr/local/InfEngine' );

# Config paths.
use constant INF_ENGINE_SERVER_CONFIG				=> INF_ENGINE_PATH_CONF + 'InfServer.conf';
use constant AP_PROCESS_SERVER_CONFIG				=> INF_ENGINE_PATH_CONF + 'ap-process-server.conf';
use constant INF_ENGINE_COMPILER_CONFIG 			=> INF_ENGINE_PATH_CONF + 'InfCompiler.conf';
use constant INF_ENGINE_ENVIRONMENT_CONFIG			=> INF_ENGINE_PATH_CONF + 'Environment.conf';
use constant INF_ENGINE_ELLIPSIS_COMPILER_CONFIG	=> INF_ENGINE_PATH_CONF + 'EllipsisCompiler.conf';

# Binaries paths.
use constant AP_PROCESS_SERVER_BINARY				=> INF_ENGINE_PATH_BIN + 'ap-process-server';

# Lockfile paths.
use constant INF_ENGINE_LOCK_FILE					=> INF_ENGINE_PATH_TMP + 'BuildEngine.lock';

# Log file.
use constant INF_ENGINE_LOG_FILE_PATH				=> INF_ENGINE_PATH_LOGS + 'InfEngine.log';

# Default config values.
use constant DEFAULT_ENVIRONMENT_CLEAN_RELEASES		=> 1;
use constant DEFAULT_ENVIRONMENT_CLEAN_ENGINES		=> 1;

# Default memcache server.
use constant DEFAULT_INF_SERVER_CACHE_SERVERS		=> "localhost:11211";

=head2 new( $root_path, %args )

Create new InfEngine::Server.

=over

=item root_path

path to InfEngine root.

=back

=cut
sub new {
	my ( $class, $root_path, %args ) = @_;

	if( !$root_path ) {
		$root_path = iepath( $0 )->parent()->parent();
		if( ! $root_path->is_file( INF_ENGINE_SERVER_CONFIG ) &&
			! $root_path->is_file( AP_PROCESS_SERVER_CONFIG ) &&
			! $root_path->is_file( INF_ENGINE_COMPILER_CONFIG ) &&
			! $root_path->is_file( INF_ENGINE_ENVIRONMENT_CONFIG ) ) {
			$root_path = INF_ENGINE_DEFAULT_ROOT_DIRECTORY;
		}
	}

	if( !$args{nologfile} ) {
		InfEngine::Common::LogSystem::open( $root_path + INF_ENGINE_LOG_FILE_PATH );		
	}

	return bless {
		root_path => iepath_abs( $root_path )
	}, $class;
}

sub _load_config {
	my ( $self, $config, $force ) = @_;

	# Check if config was previously loaded.
	if( !$force && exists $self->{config}{$config} ) {
		return $self->{config}{$config};
	}

	# Unload previously loaded config in force mode.
	delete $self->{config}{$config};

	if( $config eq 'inf_server' ) {
		my $iscf = $self->{config}{$config} = InfEngine::Server::Config::InfEngine->new( $self->{root_path} + INF_ENGINE_SERVER_CONFIG );

		$iscf->set( 'Cache', 'Servers', [split( /\s*,\*/, $iscf->get( 'Cache', 'Servers' ) || DEFAULT_INF_SERVER_CACHE_SERVERS )] );

		return $iscf;
	}
	elsif( $config eq 'inf_compiler' ) {
		my $iccf = $self->{config}{$config} = InfEngine::Server::Config::InfEngine->new( $self->{root_path} + INF_ENGINE_COMPILER_CONFIG );

		return $iccf;
	}
	elsif( $config eq 'process_server' ) {
		my $pscf = $self->{config}{process_server} = InfEngine::Server::Config::ProcessServer->new( $self->{root_path} + AP_PROCESS_SERVER_CONFIG );

		$pscf->set( "pidfile", iepath( $pscf->get( "pidfile" ), $self->{root_path} ) );

		return $pscf;
	}
	elsif( $config eq 'environment' ) {
		my $ecf = $self->{config}{$config} = InfEngine::Server::Config::InfEngine->new()->load( $self->{root_path} + INF_ENGINE_ENVIRONMENT_CONFIG );

		my $clean_releases = $ecf->get( 'Clean', 'Releases' );
		$clean_releases = DEFAULT_ENVIRONMENT_CLEAN_RELEASES if( !defined $clean_releases || $clean_releases ne "0" );
		if( !( $clean_releases =~ /^\d+$/ ) ) {
			die ERROR "Invalid config ".INF_ENGINE_ENVIRONMENT_CONFIG.": [Clean] Releases has to be number.";
		}
		$ecf->set( 'Clean', 'Releases', $clean_releases );

		my $clean_engines = $ecf->get( 'Clean', 'Engines' );
		$clean_engines = DEFAULT_ENVIRONMENT_CLEAN_ENGINES if( !defined $clean_engines || $clean_engines ne "0" );
		if( !( $clean_engines =~ /^\d+$/ ) ) {
			die ERROR "Invalid config ".INF_ENGINE_ENVIRONMENT_CONFIG.": [Clean] Engines has to be number.";
		}
		$ecf->set( 'Clean', 'Engines', $clean_engines );

		return $ecf;
	}

	return undef;
};

sub _check {
	my $pid = shift;
	return `ps -p $pid --no-headers` ne "" ? $pid : undef;
};

my %locks;
sub _lock {
	my ( $self, $file ) = @_;

	INFO "Locking \"$file\"";

	$file = iepath( $file, $self->{root_path} );

	# Check if current script is already locked target file.
	if( exists $self->{locks}{$file->real()} ) {
		return $self;
	}

	create_dir( $file->parent() );

	my $lock;
	unless( open( $lock, ">$file" ) and flock $lock, LOCK_EX|LOCK_NB ) {
		ERROR "Can't lock file '$file': $!";
		die "Can't lock script.\n";
	}
	$self->{locks}{$file->real()} = $lock;
	$locks{$file->real()}++;

	return $self;
};

sub _unlock {
	my ( $self, $file ) = @_;

	$file = iepath( $file, $self->{root_path} )->real();

	if( exists $self->{locks}{$file} ) {
		eval {
			flock( $self->{locks}{$file}, LOCK_UN );
			unlink $file;
		};
		delete $self->{locks}{$file};
		$locks{$file}--;
	}

	return $self;
};

sub DESTROY {
	my $self = shift;
	foreach my $lock ( sort keys %{$self->{locks}} ) {
		$self->_unlock( $lock );
	}
}
END {
	foreach my $lock ( sort keys %locks ) {
		if( $locks{$lock} ) {
			unlink $lock;
		}
	}
}

=head2 pid()

Get InfEngine server pid.

=cut
sub pid {
	my $self = shift @_;

	my $config = $self->_load_config( 'process_server' );

	my $pidfile = $config->get( 'pidfile' );
	if( !$pidfile->is_file() ) {
		return undef;
	}

	my $pid;
	if( -f $pidfile ) {
		try {
			run io( "$pidfile", '>', \$pid );
		} catch {
			ERROR "Can't open pidfile '$pidfile': $_";
			die "Can't open pidfile.\n";
		};
	}
	else {
		return undef;
	}

	$pid =~ s/^\s*//g;
	$pid =~ s/\s*$//g;
	if( $pid =~ /^$/ ) {
		return undef;
	}
	elsif( $pid !~ /^\d+$/ ) {
		ERROR "Invalid InfEngine server pid file '$pidfile': $pid";
		die "Invalid InfEngine server pid file.\n";
	}

	return _check( $pid );
};

=head2 status()

Check InfEngine server status.

=cut
sub status {
	return shift->pid() ? "RUNNING" : "NOT RUNNING";
}


=head2 start()

Start InfEngine server.

=cut
sub start {
	my $self = shift;

	INFO "Starting InfEngine server.";

	if( $self->pid() ) {
		WARNING "Can't start InfEngine server: it is running.";
		return $self;
	}

	my $config = $self->_load_config( 'process_server' );

	my $process_server = $self->{root_path}->add( AP_PROCESS_SERVER_BINARY )->quoted();
	my $config_file = $config->path()->rel( $self->{root_path} )->quoted();
	my $root_path = $self->{root_path}->quoted();

	my $server_config = $self->_load_config( 'inf_server' );

	if( !Cache::Memcached->new( servers => $server_config->get( 'Cache', 'Servers' ) )->flush_all() ) {
		WARNING "Can't flush memcached servers.";
	}


	my $res = `cd $root_path && $process_server $config_file 2>&1`;
	if( $? >> 8 ) {
		ERROR "Can't start InfEngine server: $res, $?";
		die "Can't start InfEngine server: ".( $? >> 8 )."\n";
	}

	local $SIG{ALRM} = sub {
		die ERROR "Can't start InfEngine server: timeout is expired.\n";
	};

	alarm 10;

	while( 1 ) {
		if( !$self->pid() ) {
			sleep 1;

			next;
		}

		alarm 0;
		last;
	}

	INFO "InfEngine server has started.";

	return $self;
}

=head2 stop()

Stop InfEngine server if it was started before.

=cut
sub stop {
	my $self = shift;

	INFO "Stopping InfEngine server.";

	my $pid = $self->pid();
	if( !$pid ) {
		WARNING "Can't stop InfEngine server: it isn't running.";
		return $self;
	}

	my $res = `kill -TERM $pid`;
	if( $? >> 8 ) {
		ERROR "Can't stop InfEngine server: $res\n";
		die "Can't stop InfEngine server.\n";
	}

	local $SIG{ALRM} = sub {
		die ERROR "Can't kill InfEngine server: timeout is expired.\n";
	};

	alarm 10;

	while( 1 ) {
		if( _check( $pid ) ) {
			sleep 1;

			next;
		}

		alarm 0;
		last;
	}

	INFO "InfEngine server has stopped.";

	return $self;
}

=head2 restart()

Restart InfEngine server.

=cut
sub restart {
	my $self = shift;
	INFO "Restarting InfEngine server.";
	if( $self->pid() ) {
	$self->stop();
		sleep 5;
		return $self->start();
	}
	return $self;
}

=head2 reload()

Respawn InfEngine workers.

=cut
sub respawn {
	my $self = shift @_;

	INFO "Respawning InfEngine workers.";

	my $pid = $self->pid();
	if( !$pid ) {
		WARNING "Can't respawn InfEngine workers: server wasn't started.";
		return $self;
	}

	my $res = `kill -HUP $pid`;
	if( $? >> 8 ) {
		ERROR "Can't stop InfEngine server: $res\n";
		die "Can't stop InfEngine server.\n";
	}

	sleep( 10 );

	INFO "InfEngine workers had respawned.";

	return $self;
}

=head2 build_engine( $branch, %args )

Build InfEngine from git branch and set it ready to install.

=over

=item branch

branch or tag name.

=back

ARGUMENTS: %args

=over

=over

=item jobs

build threads number.

=item compilers

build compilers.

=item tools

build tools.

=item libraries

build libraries,

=item output

reference to output variable.

=back

=back

=cut
sub build_engine {
	my ( $self, $branch, %args ) = @_;

	INFO( "InfEngine building started." );

	if( !$branch || ref $branch ) {
		die ERROR_ARG( 'branch', $branch );
	}

	foreach my $key ( keys %args ) {
		if( $key eq 'output' ) {
			if( ref $args{$key} ne "SCALAR" ) {
				die ERROR_ARG( $key, $args{$key} );
			}
		}
		elsif( $key eq 'jobs' ) {
			if( $args{$key} !~ /^\d+$/ ) {
				die ERROR_ARG( $key, $args{$key} );
			}
		}
		elsif( $key =~ /^(compilers|tools|libraries)$/ ) {
		}
		else {
			WARN_ARG( $key, $args{$key} );
			delete $args{$key};
		}
	}

	$self->lock();

	my $config = $self->_load_config( 'environment' );

	my $sources = $config->get( 'InfEngine', 'Sources' );
	if( !$sources ) {
		die ERROR "InfEngine sources don't specified.\n";
	}
	DEBUG "InfEngine sources: $sources";
	
	my $build_dir = create_tmp_dir( $self->{root_path} + INF_ENGINE_PATH_ENGINES );
	InfEngine::Server::Engine->new( $build_dir )->build( $config->get( 'InfEngine', 'Sources' ), $branch, %args );
	INFO( "InfEngine successfully builded." );
	
	symlink( iepath( $build_dir )->rel( $self->{root_path} ), $self->{root_path} + INF_ENGINE_LINK_READY, force => 1 );

	$build_dir->unlink_on_destroy( 0 );
	INFO( "InfEngine is ready to install." );

	return $self->clean()->unlock();
}

#
#	Install new InfEngine.
#
#	ARGUMENTS: %args
#		output		- output buffer.
#		dldata		- binary DL data.
#		eldata		- binary ellipsis data.
#		dlsources	- DL Data sources.
#		elsources	- ellipsis sources.
#		engine		- path to new InfEngine. Default: 'ready' InfEngine.
#		aliases		- aliases file. []
#
#	FLAGS:
#		strict		- use strict DL compilation.
#		compilers	- install compilers.
#		tools		- install tools.
#		libraries	- install libraries.
#
sub install_engine {
	my ( $self, %args ) = @_;

	INFO "Installing InfEngine.";

	foreach my $key ( keys %args ) {
		if( $key eq 'output' ) {
			if( ref( $args{$key} ) ne "SCALAR" ) {
				die ERROR_ARG( $key, $args{$key} );
			}
		}
		elsif( $key eq 'dldata' || $key eq 'eldata' ) {
			$args{$key} = iepath( $args{$key} );
			if( !$args{$key}->is_file() ) {
				die ERROR uc( substr $key, 0, 3 ).substr( $key, 3 )." path is invalid: $args{$key}";
			}
		}
		elsif( $key eq 'dlsources' || $key eq 'elsources' ) {
			$args{$key} = iepath( $args{$key} );
			if( !$args{$key}->is_dir() ) {
				die ERROR uc( substr $key, 0, 3 ).substr( $key, 3 )." path is invalid: $args{$key}";
			}
		}
		elsif( $key eq 'engine' ) {
			$args{$key} = iepath( $args{$key} );
			if( !$args{$key}->is_dir() ) {
				die ERROR "Engine path is invalid: $args{$key}";
			}	
		}
		elsif( $key eq 'aliases' ) {
			if( $args{$key} ) {
				$args{$key} = iepath( $args{$key} );
				if( !$args{$key}->is_file() ) {
					die ERROR "Aliases path is invalid: $args{$key}";
				}
			}
		}
		elsif( $key eq 'strict' || $key eq 'compilers' || $key eq 'tools' || $key eq 'libraries' ) {

		}
		else {
			WARN_ARG( $key, $args{$key} );
			delete $args{$key};
		}
	}

	if( exists $args{dldata} && exists $args{dlsources} ) {
		die ERROR "Restricted use of dldata and dlsources.";
	}
	if( exists $args{eldata} && exists $args{elsources} ) {
		die ERROR "Restricted use of eldata and elsources.";
	}

	$self->lock();

	my $engine = undef;
	if( $args{engine} ) {
		$engine = InfEngine::Server::Engine->new( $args{engine} );
		INFO "Using custom engine path: ".iepath_abs( $args{engine} );
	}
	else {
		$engine = InfEngine::Server::Engine->new( $self->{root_path} + INF_ENGINE_LINK_READY );
	}
	my $release = InfEngine::Server::Engine->new( $self->{root_path} + INF_ENGINE_LINK_RELEASE );

	# Prepare aliases.
	my $dldata_dir = create_tmp_dir( $self->{root_path} + INF_ENGINE_PATH_TMP );
	if( exists $args{aliases} ) {
		if( $args{aliases}->is_file() ) {
			INFO "Using custom aliases: $args{aliases}";
			$args{aliases} = $args{aliases}->real();
		}
		else {
			die ERROR "Invalid aliases path: $args{aliases}";
		}
	}
	else {
		# Keep aliases.
		if( $release->aliases() && $release->aliases()->is_exists() ) {
			$args{aliases} = $release->aliases()->real();
			INFO "Using previous aliases: ".$release->aliases();
		}
		else {
			INFO "There is no aliases.";
			$args{aliases} = "";
		}
	}

	# Prepare DL data.
	if( exists $args{dldata} ) {
		if( $engine->check( dldata => $args{dldata} ) ) {
			INFO "Using custom DL data: $args{dldata}";
		}
		else {
			die ERROR "Can't install engine and custom DL data: engine and DL data is incompatable.";
		}
	}
	elsif( exists $args{dlsources} ) {
		INFO "Using custom DL sources: $args{dlsources}";
		$args{dldata} = iepath( $dldata_dir ) + INF_ENGINE_DLDATA_FILE;
		$engine->compile_dldata( $args{dlsources},
								 $self->{root_path} + INF_ENGINE_COMPILER_CONFIG,
								 $args{dldata},
								 output => $args{output},
								 strict => $args{strict},
								 aliases => $args{aliases} );
	}
	else {
		my $config = $self->_load_config( 'inf_compiler' );

		if( $release->dldata() && $engine->check( dldata => $release->dldata() ) ) {
			$args{dldata} = $release->dldata();
			$args{dlsources} = $release->dlsources();
			INFO "Using previous binary DL data: ".$release->dldata()->rel( $self->{root_path} );
		}
		elsif( $release->dlsources() ) {
			$args{dldata} = iepath( $dldata_dir ) + INF_ENGINE_DLDATA_FILE;
			$engine->compile_dldata( $release->dlsources(), 
									 $self->{root_path} + INF_ENGINE_COMPILER_CONFIG,
									 $args{dldata},
									 output => $args{output},
									 strict => $args{strict},
									 aliases => $args{aliases} );

			$args{dlsources} = $release->dlsources();
			INFO "Using previous DL data sources: ".$release->dlsources()->rel( $self->{root_path} );
		}
		elsif( !$self->{root_path}->add( INF_ENGINE_LINK_RELEASE )->is_dir() ) {
			INFO "Initial installation without DL data.";
		}
		else {
			die ERROR "Can't install InfEngine: There is not compatable DL data.";
		}
	}

	# Prepare ellipsis data.
	my $eldata_dir = create_tmp_dir( $self->{root_path} + INF_ENGINE_PATH_TMP );
	if( exists $args{eldata} ) {
		if( $engine->check( eldata => $args{eldata} ) ) {
			INFO "Using custom ellipsis data: $args{eldata}";
		}
		else {
			die ERROR "Can't install engine and custom ellipsis data: engine and ellipsis data is incompatable.";
		}
	}
	elsif( exists $args{elsources} ) {
		INFO "Using custom ellipsis sources: $args{elsources}";
		$args{eldata} = iepath( $eldata_dir ) + INF_ENGINE_ELDATA_FILE;
		$engine->compile_eldata( $args{elsources}, 
								 $self->{root_path} + INF_ENGINE_ELLIPSIS_COMPILER_CONFIG,
								 $args{eldata},
								 output => $args{output} );
	}
	else {
		if( $release->eldata() && $engine->check( eldata => $release->eldata() ) ) {
			$args{eldata} = $release->eldata();
			$args{elsources} = $release->elsources();
			INFO "Using previous binary ellipsis data: ".$release->eldata()->rel( $self->{root_path} );
		}
		elsif( $release->elsources() ) {
			$args{eldata} = iepath( $eldata_dir ) + INF_ENGINE_ELDATA_FILE;
			$engine->compile_eldata( $release->elsources(),
									 $self->{root_path} + INF_ENGINE_ELLIPSIS_COMPILER_CONFIG,
									 $args{eldata},
									 output => $args{output} );
			
			$args{elsources} = $release->elsources();
			INFO "Using previous ellipsis data sources: ".$release->elsources()->abs( $self->{root_path} );
		}
		elsif( !$self->{root_path}->add( INF_ENGINE_LINK_RELEASE )->is_dir() ) {
			INFO "Initial installation without ellipsis data.";
		}
		else {
			INFO "Installation without ellipsis data.";
		}
	}

	# Install engine.
	my $target_dir = create_tmp_dir( $self->{root_path} + INF_ENGINE_PATH_RELEASES );
	$engine->copy_engine( $target_dir, compilers => $args{compilers}, tools => $args{tools}, libraries => $args{libraries} );
	$engine = InfEngine::Server::Engine->new( $target_dir );

	if( $args{dldata} || $args{dlsources} || $args{eldata} || $args{elsources} || $args{aliases} ) {
		$engine->install( dldata => $args{dldata},
						  dlsources => $args{dlsources},
						  eldata => $args{eldata},
						  elsources => $args{elsources},
						  aliases => $args{aliases} );
	}

	symlink( iepath( $target_dir )->rel( $self->{root_path} ), $self->{root_path} + INF_ENGINE_LINK_RELEASE, force => 1 );
	$target_dir->unlink_on_destroy( 0 );

	if( !$self->{root_path}->add( AP_PROCESS_SERVER_BINARY )->is_exists() ) {
		copy( $engine->get( 'ap-process-server' ), $self->{root_path} + AP_PROCESS_SERVER_BINARY );
	}

	return $self->restart()->clean()->unlock();
}

=head2 update_data( %args )

Update DL and/or ellipsis data.

ARGUMENTS: %args

=over

=over

=item dldata

path to DL data binary file. (Incompatible with B<dlsources>)

=item dlsources

path to DL data sources. (Incompatible with B<dldata>)

=item eldata

path to ellipsis data binary file. (Incompatible with B<elsources>)

=item elsources

path to ellipsis data sources. (Incompatible with B<eldata>)

=item output

reference to output variable.

=item strict

use strict DL compilation.

=back

=back

=cut
sub update_data {
	my ( $self, %args ) = @_;

	INFO "Updating Data.";

	foreach my $key ( keys %args ) {
		if( $key eq 'output' ) {
			if( ref( $args{$key} ) ne "SCALAR" ) {
				die ERROR_ARG( $key, $args{$key} );
			}
		}
		elsif( $key eq 'dldata' || $key eq 'eldata' ) {
			$args{$key} = iepath( $args{$key} );
			if( !$args{$key}->is_file() ) {
				die ERROR uc( substr $key, 0, 3 ).substr( $key, 3 )." path is invalid: $args{$key}";
			}
		}
		elsif( $key eq 'dlsources' || $key eq 'elsources' ) {
			$args{$key} = iepath( $args{$key} );
			if( !$args{$key}->is_dir() ) {
				die ERROR uc( substr $key, 0, 3 ).substr( $key, 3 )." path is invalid: $args{$key}";
			}
		}
		elsif( $key eq 'aliases' ) {
			if( $args{$key} ) {
				$args{$key} = iepath( $args{$key} );
				if( !$args{$key}->is_file() ) {
					die ERROR uc( substr $key, 0, 3 ).substr( $key, 3 )." path is invalid: $args{$key}";
				}
			}
		}
		elsif( $key eq 'strict' ) {

		}
		else {
			WARN_ARG( $key, $args{$key} );
			delete $args{$key};
		}
	}

	if( exists $args{dldata} && exists $args{dlsources} ) {
		die ERROR "Restricted use of dldata and dlsources.";
	}
	if( exists $args{eldata} && exists $args{elsources} ) {
		die ERROR "Restricted use of eldata and elsources.";
	}

	$self->lock();

	my $engine = InfEngine::Server::Engine->new( $self->{root_path} + INF_ENGINE_LINK_RELEASE );

	my $config = $self->_load_config( 'inf_compiler' );

	my $tmp_dir = create_tmp_dir( $self->{root_path} + INF_ENGINE_PATH_TMP );

	# Prepare DL data.
	if( exists $args{dldata} ) {
		if( $engine->check( dldata => $args{dldata} ) ) {
			INFO "Update DL data binary: $args{dldata}";
		}
		else {
			die ERROR "DL data is incompatible.";
		}
	}
	elsif( exists $args{dlsources} ) {
		INFO "Update DL data from sources: $args{dlsources}";
		$args{dldata} = iepath( $tmp_dir ) + INF_ENGINE_DLDATA_FILE;
		$engine->compile_dldata( $args{dlsources},
								 $self->{root_path} + INF_ENGINE_COMPILER_CONFIG,
								 $args{dldata},
								 output => $args{output},
								 strict => $args{strict} );
	}

	# Prepare ellipsis data.
	if( exists $args{eldata} ) {
		if( $engine->check( eldata => $args{eldata} ) ) {
			INFO "Update ELData binary: $args{eldata}";
		}
		else {
			die ERROR "DLData is incompatible.";
		}
	}
	elsif( exists $args{elsources} ) {
		INFO "Update ELData from sources: $args{elsources}";
		$args{eldata} = iepath( $tmp_dir ) + INF_ENGINE_ELDATA_FILE;
		$engine->compile_eldata( $args{elsources}, 
								 $self->{root_path} + INF_ENGINE_ELLIPSIS_COMPILER_CONFIG,
								 $args{eldata},
								 output => $args{output} );
	}

	delete $args{strict};
	delete $args{output};
	
	$engine->install( %args );

	return $self->restart()->clean()->unlock();
}

sub _clean {
	my ( $dir, $exclude, $limit ) = @_;

	$exclude = $exclude->real();
	
	my $counter = 0;
	return 0 if( !$dir->is_dir() );
	
	my @files;
	opendir DIR, $dir or die ERROR "Can't open directory '$dir': $!";
	foreach my $file ( sort { $b cmp $a } readdir DIR ) {

		# Pass . and .. dirs.
		next if $file =~ /^\.\.?$/;

		my $file = ( $dir + $file )->real();

		next if( $file eq $exclude );

		push @files, $file;
	}
	closedir DIR;

	foreach ( 1..$limit ) {
		shift @files;
	}

	foreach my $file ( @files ) {
		$file->remove();
	}
	
	return scalar( @files );
};

=head2 clean()

Clean old releases, DL/ellipsis data and engines.

=cut
sub clean {
	my $self = shift @_;

	INFO "Clean InfServers...";

	$self->lock();

	my $config = $self->_load_config( 'environment' );

	# Clean engines.
	my $count = _clean(
			$self->{root_path} + INF_ENGINE_PATH_ENGINES,
			$self->{root_path} + INF_ENGINE_LINK_READY,
			$config->get( 'Clean', 'Engines' ) );
	if( $count ) {
		INFO "Deleted $count engines.";
	};

	# Clean releases.
	$count = _clean(
			$self->{root_path} + INF_ENGINE_PATH_RELEASES,
			$self->{root_path} + INF_ENGINE_LINK_RELEASE,
			$config->get( 'Clean', 'Releases' ) );
	if( $count ) {
		INFO "Deleted $count releases.";
	};

	# Clean DL and ellipsis data.
	InfEngine::Server::Engine->new( $self->{root_path} + INF_ENGINE_LINK_RELEASE )->clean( $config->get( 'Clean', 'DLData' ), $config->get( 'Clean', 'ELData' ) );

	return $self->unlock();
}

=head2 engine()

Get current engine.

=cut
sub release {
	return InfEngine::Server::Engine->new( shift->{root_path} + INF_ENGINE_LINK_RELEASE );
}

=head2 ready()

Get ready to install engine.

=cut
sub ready {
	return InfEngine::Server::Engine->new( shift->{root_path} + INF_ENGINE_LINK_READY );
}

=head2 root_path()

Get current root path

=cut
sub root_path {
	return shift->{root_path};
}

=head2 tmp_path()

Get current tmp path.

=cut
sub tmp_path {
	return shift->{root_path} + INF_ENGINE_PATH_TMP;
}

sub config {
	my ( $self, $config ) = @_;
	if( $config eq 'InfCompiler' ) {
		return $self->{root_path} + INF_ENGINE_COMPILER_CONFIG;
	}
	elsif( $config eq 'EllipsisCompiler' ) {
		return $self->{root_path} + INF_ENGINE_ELLIPSIS_COMPILER_CONFIG;
	}
	elsif( $config eq 'DefaultDLData' ) {
		my $config = $self->_load_config( 'environment' );
		return $config->get( 'InfEngine', 'DLData' );
	}
	elsif( $config eq 'DefaultELData' ) {
		my $config = $self->_load_config( 'environment' );
		return $config->get( 'InfEngine', 'ELData' );
	}
	else {
		return iepath();
	}
}

sub lock {
	return shift->_lock( INF_ENGINE_LOCK_FILE );
}

sub unlock {
	return shift->_unlock( INF_ENGINE_LOCK_FILE );
}

sub get {
	my ( $self, $name ) = @_;
	if( $name eq 'ready' ) {
		return $self->{root_path} + INF_ENGINE_LINK_READY;
	}
	elsif( $name eq 'root_path' ) {
		return $self->{root_path};
	}
	elsif( $name eq 'tmp_path' ) {
		return shift->{root_path} + INF_ENGINE_PATH_TMP;
	}
	else {
		return iepath();
	}
}

1
