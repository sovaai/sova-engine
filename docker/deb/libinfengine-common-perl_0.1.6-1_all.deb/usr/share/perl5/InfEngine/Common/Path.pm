package InfEngine::Common::Path;

use strict;
use warnings;

=head1 NAME

InfEngine::Common::Path - Easy path manipulation.

=cut

use Cwd qw( abs_path );
use File::Spec::Functions qw( abs2rel rel2abs catdir catfile file_name_is_absolute );
use File::Basename;
use File::Path 2.06 qw(remove_tree make_path);

use InfEngine::Common::LogSystem;

use overload 
    '""' => sub { shift->{path}; },
    'eq' => sub { shift->{path} eq shift; },
    '+' => 'add',
    '+=' => sub { my $self = shift; $self = $self + shift; return $self; },
    '/' => 'add',
    '/=' => sub { my $self = shift; $self = $self + shift; return $self; };


=head2 new( $path, $rootpath )

Construct new path.

	path - path to file.
	rootpath - root directory, if path is relative. Default: current directory.

=cut
sub new {
	my ( $class, $path, $rootpath ) = @_;

	$path = "" if( !$path );

	if( $rootpath ) {
		if( file_name_is_absolute( $path ) ) {
			DEBUG "Path '$path' is absolute. RootPath '$rootpath' has ignored.";
		}
		else {
			$path = catdir( $rootpath, $path );
		}
	}

	return bless {
		path => "$path"
	}, $class;
}

=head2 abs()

	Get absolute canon path.

=cut
sub abs {
	my $self = shift @_;
	return InfEngine::Common::Path->new( rel2abs( "$self" ) );
}

=head2 real()

	Get real path without soft or hard links.

=cut
sub real {
	my $self = shift @_;
	return InfEngine::Common::Path->new( abs_path( rel2abs( "$self" ) ) ) || $self->abs();
}

=head2( $rootpath )

	Get relatve to $rootpath path.

=cut
sub rel {
	my ( $self, $rootpath ) = @_;
	return InfEngine::Common::Path->new( abs2rel( "".$self->abs(), $rootpath ) );
}

=head2 quoted()

	Get quoted path to use it in system call.

=cut;
sub quoted {
	my $path = "".shift;
	$path =~ s/\\/\\\\/g;
	$path =~ s/\"/\\\"/g;
	return qq|"$path"|;
}

=head2 add( $subpath )

	Append $subpath to the path.

=cut
sub add {
	my ( $self, $subpath ) = @_;
	chomp( $subpath );
	return InfEngine::Common::Path->new( catdir( "$self", $subpath ) );
}

=head2 parent()

	Get parent dir.

=cut
sub parent {
	my $self = shift;
	if( $self eq '.' ) {
		$self = $self->abs();
	}
	return InfEngine::Common::Path->new( dirname( $self ) );
}

=head2 name()

	Get name of file or dir.

=cut
sub name {
	return basename( ''.shift );
}

=head2 is_dir()

	Check if path represents existing directory.

=cut
sub is_dir {
	return -d shift->abs();
}

=head2 is_file()

	Check if path represents existing file.

=cut
sub is_file {
	my ( $self, $file ) = @_;
	if( $file ) {
		return $self->add( $file )->is_file();
	}
	else {
		return -f shift->abs();		
	}
}

=head2 is_link()

	Check if path represents soft link.

=cut
sub is_link {
	my ( $self, $file ) = @_;
	if( $file ) {
		return $self->add( $file )->is_link();
	}
	else {
		return -l shift->abs();		
	}
}

=head2 is_exists()

Check if path exists.

=cut
sub is_exists {
	my ( $self, $file ) = @_;
	if( $file ) {
		return $self->add( $file )->is_exists();
	}
	else {
		return -e shift->abs();		
	}
}

=head2 remove()

	Remove file or folder.

=cut
sub remove {
	my $self = shift;

	remove_tree( "$self", { verbose => 0, error => \my $res } );
	if( $#$res != -1 ) {
		die ERROR "Can't remove '$self': $res->[0]";
	}

	return $self;
}

=head2 clear()

If path is direcotry, remove all files and directories inside.

=cut
sub clear {
	my $self = shift;

	remove_tree( "$self", { verbose => 0, error => \my $res, keep_root => 1 } );
	if( $#$res != -1 ) {
		die ERROR "Can't remove '$self': $res->[0]";
	}

	return $self;
}

1